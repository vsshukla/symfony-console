<?php

use App\TimeCommand;

require __DIR__ . '/vendor/autoload.php';

use Symfony\Component\Console\Application;

$app = new Application();
$app->add(new TimeCommand());
$app->run();
